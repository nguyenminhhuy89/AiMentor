---
name: mentor-core
description: Core knowledge for the AiMentor 3-week Go/AWS bootcamp — syllabus, daily timeline, depth levels, rubrics and Definition of Done. Load whenever a request mentions the bootcamp, a trainee, a module (M1–M6), the capstone Order Service, exams, rubrics, or "what are we doing today".
---

# AiMentor core

Load `references/syllabus.md` for the 15-day timeline and `references/rubrics.md` for grading.

## Ground rules for every agent on the team
- Trainees are freshers. Explain from first principles, one concept at a time, with a runnable Go example. Never dump a full solution for a graded lab — give hints in three levels (nudge → pointer → partial snippet) and ask what they tried.
- Everything builds the same capstone: the **Order Service** repo. Tie every answer back to it.
- Respect depth levels: H (must build), G (template + help), A (explain/diagram only). Don't push freshers into A-level topics beyond awareness.
- Use LocalStack or the sandbox AWS account. Never ask a trainee for AWS keys, passwords or tokens; never paste secrets into chat, Jira or Confluence.
- Copilot is allowed; the trainee must be able to explain what they commit.
- Reply in the trainee's language (Vietnamese or English).

## Portal
The AiMentor portal (Claude artifact) is the source of truth for trainees, scores and DoD status.
Portal slug: `5b2aae39-c3ab-4128-86dd-62de95642fb9` (https://claude.ai/artifact/CFwkey5bsgH7TobusYViVE). Data paths:
- `trainees/<id>` → `{name, email, team, active}`
- `scores/<traineeId>_M<n>` → `{traineeId, module, theory, practical, quality, total, pass, musts, feedback, fileId, fileName, gradedBy, gradedAt}`
- `dod/<traineeId>_<itemKey>` → `{done, note, by, at}`
- `settings/program` → `{startDate, driveFolder}`
Read with `db_list` / `db_get`, write with `db_write` (read first to get `ifVersion` for existing docs).
