# ai-mentor — AI training team for the AiMentor bootcamp

3-week (15 working days) cloud-native Go bootcamp for freshers: Go (Gin) + OpenAPI/oapi-codegen v2, AWS data/encryption, async events, gateway/network/security, runtime/IaC/CI-CD, quality/observability/ops.

## Agents
| Agent | Role |
|---|---|
| mentor-lead | Orchestrator: daily plan, pace, routing, weekly report, escalation |
| tutor-contract-api | M1 Contract & Core API (D1–D5) |
| tutor-data-encryption | M2 Data & Encryption (D6–D8) |
| tutor-async-events | M3 Async & Event-Driven (D9–D10) |
| tutor-gateway-security | M4 Gateway, Network & Security (D11–D12) |
| tutor-runtime-cicd | M5 Runtime, IaC & CI/CD (D13–D14) |
| tutor-quality-ops | M6 Quality, Observability & Ops (every day + D15) |
| exam-grader | Scans Google Drive exams, grades by rubric, saves to portal |
| dod-auditor | Runs DoD checks on code with evidence |

## Skills
`/daily-plan` · `/grade-exams [M1–M6|new]` · `/module-quiz D<n> | M<n> exam` · `/dod-check <trainee> <repo>` · `/progress-report [week n]` · `mentor-core` (syllabus + rubrics, loaded automatically)

## Connections
- **Google Drive** (claude.ai connector, already connected): exams live in `AiMentor/Exams/M<n>-<name>/`, files named `<TraineeID>_<FullName>_M<n>`.
- **AiMentor portal** (Claude artifact): https://claude.ai/artifact/CFwkey5bsgH7TobusYViVE — scores, DoD and trainees are read/written with the artifact database tools.
- Optional: Jira / Confluence / Atlassian Rovo connectors for posting plans, runbooks and reports; GitHub for repo checks.
